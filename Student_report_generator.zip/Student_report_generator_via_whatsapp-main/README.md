# Student_report_generator_via_whatsapp
It is build to reduce the work load of faculty to make the report manually
